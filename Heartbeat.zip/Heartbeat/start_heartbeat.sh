#!/bin/bash
DIR="$(dirname "$0")"
"$DIR/heartbeat"